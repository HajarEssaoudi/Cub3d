/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hqannouc <hqannouc@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/16 21:16:43 by hes-saou          #+#    #+#             */
/*   Updated: 2025/11/18 15:50:55 by hqannouc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/cube.h"

void	my_mlx_pixel_put(t_img_data *data, int x, int y, int color)
{
	char	*dst;

	dst = data->addr + (y * data->line_length + x * (data->bpp / 8));
	*(unsigned int*)dst = color;
}

void	init_img(t_game *game)
{
	game->img_data = gc_malloc(sizeof(t_img_data));
	if (!game->img_data)
		return ;
	game->img_data->img = mlx_new_image(game->mlx, (game->win_width), (game->win_height));
	game->img_data->addr = mlx_get_data_addr(
			game->img_data->img,
			&game->img_data->bpp,
			&game->img_data->line_length,
			&game->img_data->endian);
}

void	check_key(int keycode, t_game *game)
{
	if (keycode == W)
		game->keys->w = 1;
	else if (keycode == S)
		game->keys->s = 1;
	else if (keycode == D)
		game->keys->d = 1;
	else if (keycode == A)
		game->keys->a = 1;
	else if (keycode == LEFT_ARROW)
		game->keys->left = 1;
	else if (keycode == RIGHT_ARROW)
		game->keys->right = 1;
}

void	move_player(t_game *game, double *x, double *y)
{
	if (game->keys->w == 1)
	{
		*x += cos(game->player.angle) * 0.1;
		*y += sin(game->player.angle) * 0.1;
	}	
	if (game->keys->s == 1)
	{
		*x -= cos(game->player.angle) * 0.1;
		*y -= sin(game->player.angle) * 0.1;
	}
	if (game->keys->d == 1)
	{
		*x -= sin(game->player.angle) * 0.1;
		*y += cos(game->player.angle) * 0.1;
	}
	if (game->keys->a == 1)
	{
		*x += sin(game->player.angle) * 0.1;
		*y -= cos(game->player.angle) * 0.1;
	}
	if (game->keys->left == 1)
		game->player.angle -= deg_to_rad(5);
	if (game->keys->right == 1)
		game->player.angle += deg_to_rad(5);
}

int	handle_keypress(int keycode, t_game *game)
{
	double	x;
	double	y;
	static int	flag;

	if (keycode == ESC)
	{
		mlx_destroy_window(game->mlx, game->win);
		gc_free_all();
		exit(0);
	}
	x = game->player.x;
	y = game->player.y;
	if (!game->keys)
		return (0);
	check_key(keycode, game);
	move_player(game, &x, &y);
	if (game->scene.map[(int)(y)][(int)(x)] != '1' && game->scene.map[(int)(y)][(int)(x)] != '\0')
	{
		game->player.x = x;
		game->player.y = y;
	}
	mlx_clear_window(game->mlx, game->win);
	draw_3d_fov(game);
	if (keycode == M)
	{
		if (flag == 0)
			flag = 1;
		else
			flag = 0;
	}
	if (flag == 1)
		draw_mini_map(game); //bonus
	return (0);
}

int	handle_keyrelease(int keycode, t_game *game)
{
	if (!game->keys)
		return (0);
	if (keycode == W)
		game->keys->w = 0;
	else if (keycode == S)
		game->keys->s = 0;
	else if (keycode == D)
		game->keys->d = 0;
	else if (keycode == A)
		game->keys->a = 0;
	else if (keycode == RIGHT_ARROW)
		game->keys->right = 0;
	else if (keycode == LEFT_ARROW)
		game->keys->left = 0;
	return (0);
}

// void move_mouse

void render_window(t_game *game)
{
	game->mlx = mlx_init();
	game->win = mlx_new_window(game->mlx, game->win_width, game->win_height, "Cub3D");
	init_img(game);
	init_textures(game);
	draw_3d_fov(game);
	mlx_hook(game->win, 2, 1 << 0, handle_keypress, game);
	mlx_hook(game->win, 3, 1 << 1, handle_keyrelease, game);
	mlx_hook(game->win, 17, 0, handle_close_button, game);
	mlx_loop(game->mlx);
}
